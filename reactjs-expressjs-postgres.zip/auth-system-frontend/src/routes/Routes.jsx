import React, { Suspense } from "react";
import { Route, Routes as ReactRouterRoutes } from "react-router-dom";
import RegisterPage from "../pages/RegisterPage";
import LoginPage from "../pages/LoginPage";
import ProfilePage from "../pages/ProfilePage";
import AdminDashboardPage from "../pages/AdminDashboardPage";
import ProtectedRoute from "../components/ProtectedRoute"; // A wrapper to protect routes
import useAuth from "../hooks/useAuth"; // Custom hook for authentication state
import ErrorBoundary from "../components/ErrorBoundary"; // Custom error boundary component
import AuthLayout from "../components/layout/AuthLayout"; // Layout component
import UserManagement from "../pages/UserManagement";
import PublicPage from "../pages/PublicPage";

// Fallback loading component for Suspense
const Loading = () => <div>Loading...</div>;

const Routes = () => {
  const { isAuthenticated, isAdmin } = useAuth();

  return (
    <Suspense fallback={<Loading />}>
      <ReactRouterRoutes>
        {/* Blank Layout Routes (e.g. Register, Login) */}
        <Route
          path="/register"
          element={
            <ErrorBoundary>
              <RegisterPage />
            </ErrorBoundary>
          }
        />
        <Route
          path="/login"
          element={
            <ErrorBoundary>
              <LoginPage />
            </ErrorBoundary>
          }
        />

        {/* Layout-based Routes (requires authenticated user) */}
        <Route element={<AuthLayout />}>
          {/* Home Page (Logged in / Not logged in state) */}
          <Route
            path="/"
            element={
              <ErrorBoundary>
                {isAuthenticated ? <ProfilePage /> : <LoginPage />}
              </ErrorBoundary>
            }
          />

          {/* Profile Page */}
          <Route
            path="/profile"
            element={
              <ErrorBoundary>
                <ProtectedRoute isAuthenticated={isAuthenticated}>
                  <ProfilePage />
                </ProtectedRoute>
              </ErrorBoundary>
            }
          />
          <Route
            path="/users"
            element={
              <ErrorBoundary>
                {/* <ProtectedRoute isAuthenticated={isAuthenticated}> */}
                  <UserManagement />
                {/* </ProtectedRoute> */}
              </ErrorBoundary>
            }
          />
          <Route
            path="/public-page"
            element={
              <ErrorBoundary>
                {/* <ProtectedRoute isAuthenticated={isAuthenticated}> */}
                  <PublicPage />
                {/* </ProtectedRoute> */}
              </ErrorBoundary>
            }
          />
          {/* Admin Dashboard Page */}
          <Route
            path="/admin-dashboard"
            element={
              <ErrorBoundary>
                {/* <ProtectedRoute isAuthenticated={isAuthenticated && isAdmin}> */}
                  <AdminDashboardPage />
                {/* </ProtectedRoute> */}
              </ErrorBoundary>
            }
          />
        </Route>
      </ReactRouterRoutes>
    </Suspense>
  );
};

export default Routes;
