import React from 'react';
import { Box, Container, Typography, Button, Grid, Paper, Divider } from '@mui/material';

const PublicPage = () => {
  return (
    <Box sx={{ flexGrow: 1, bgcolor: 'background.default', p: 3 }}>
      {/* Main Container */}
      <Container sx={{ mt: 4 }}>
        <Typography variant="h3" gutterBottom align="center">
          Welcome to Our Public Page
        </Typography>

        {/* About Section */}
          <Grid item xs={12} sm={6}>
            <Paper sx={{ p: 3, display: 'flex', flexDirection: 'column', height: '100%' }}>
              <Typography variant="h5" gutterBottom>
                About Us
              </Typography>
              <Typography variant="body1" color="textSecondary">
                We are committed to providing the best services to our users. On this page, you can find information
                about what we offer and how we can help you. Our mission is to ensure that everyone has access to
                quality resources and support.
              </Typography>
            </Paper>
          </Grid>

    

     
      </Container>
    </Box>
  );
};

export default PublicPage;
