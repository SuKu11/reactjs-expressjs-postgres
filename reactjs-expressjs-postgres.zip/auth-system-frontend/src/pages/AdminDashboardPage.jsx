import React from 'react';
import { Box, Grid, Paper, Typography, Container, Divider } from '@mui/material';

const AdminDashboardPage = () => {
  return (
    <Box sx={{ flexGrow: 1, bgcolor: 'background.default', p: 3 }}>
      <Container sx={{ mt: 4 }}>
        <Typography variant="h4" gutterBottom>
          Admin Dashboard
        </Typography>
        {/* Grid for Dashboard Widgets */}
        <Grid container spacing={3}>
          <Grid item xs={12} sm={6} md={4}>
            <Paper sx={{ p: 2, display: 'flex', flexDirection: 'column', height: '100%' }}>
              <Typography variant="h6" gutterBottom>
                Total Users
              </Typography>
              <Typography variant="h4">150</Typography>
            </Paper>
          </Grid>

          <Grid item xs={12} sm={6} md={4}>
            <Paper sx={{ p: 2, display: 'flex', flexDirection: 'column', height: '100%' }}>
              <Typography variant="h6" gutterBottom>
                Active Sessions
              </Typography>
              <Typography variant="h4">30</Typography>
            </Paper>
          </Grid>

          <Grid item xs={12} sm={6} md={4}>
            <Paper sx={{ p: 2, display: 'flex', flexDirection: 'column', height: '100%' }}>
              <Typography variant="h6" gutterBottom>
                Sales Today
              </Typography>
              <Typography variant="h4">$1200</Typography>
            </Paper>
          </Grid>
        </Grid>
      </Container>
      <Divider sx={{ mt: 3 }} />
    </Box>
  );
};

export default AdminDashboardPage;
