import React from 'react';
import { Container, Box } from '@mui/material';
import LoginForm from '../components/forms/LoginForm';

const LoginPage = () => {
    return (
        <Container component="main" maxWidth="xs" style={{ height: '100vh' }}>
            <Box
                display="flex"
                flexDirection="column"
                justifyContent="center"
                alignItems="center"
                height="100%"
            >
                <LoginForm />
            </Box>
        </Container>
    );
};

export default LoginPage;