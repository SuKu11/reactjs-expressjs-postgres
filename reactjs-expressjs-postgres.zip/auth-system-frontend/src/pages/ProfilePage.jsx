import React, { useEffect, useState } from 'react';
import { Box, Typography, Button, Card, CardContent, CircularProgress } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import  useAuth  from '../hooks/useAuth'; // Assuming you're using AuthContext

const ProfilePage = () => {
  const { isAuthenticated, logout } = useAuth();
  const [userDetails, setUserDetails] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login'); // Redirect to login page if not authenticated
    } else {
      // Simulate API call to fetch user details
      fetchUserDetails();
    }
  }, [isAuthenticated, navigate]);

  const fetchUserDetails = async () => {
    try {
      // Simulating an API call to get user details
      const response = await fakeApiGetUserDetails();
      setUserDetails(response);
      setLoading(false);
    } catch (err) {
      setLoading(false);
      console.error("Error fetching user details", err);
    }
  };

  // Simulate an API call (replace with actual API call)
  const fakeApiGetUserDetails = () => {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          name: 'John Doe',
          email: 'john.doe@example.com',
          role: 'user',
        });
      }, 1000);
    });
  };

  const handleLogout = () => {
    logout(); // Clear authentication data
    navigate('/login'); // Redirect to login page
  };

  if (loading) {
    return (
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          height: '100vh',
        }}
      >
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box
      sx={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        minHeight: '100vh',
        padding: 3,
      }}
    >
      <Card sx={{ maxWidth: 400, width: '100%' }}>
        <CardContent>
          <Typography variant="h5" gutterBottom>
            Profile
          </Typography>
          <Typography variant="h6">Name: {userDetails?.name}</Typography>
          <Typography variant="body1">Email: {userDetails?.email}</Typography>
          <Typography variant="body2" color="textSecondary">
            Role: {userDetails?.role}
          </Typography>
          <Button
            variant="contained"
            color="secondary"
            fullWidth
            sx={{ marginTop: 2 }}
            onClick={handleLogout}
          >
            Logout
          </Button>
        </CardContent>
      </Card>
    </Box>
  );
};

export default ProfilePage;
