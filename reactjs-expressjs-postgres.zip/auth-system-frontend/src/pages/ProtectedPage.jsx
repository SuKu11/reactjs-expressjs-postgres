import React, { useEffect, useState } from 'react';
import { Box, Container, Typography, Button, Grid, Paper, Divider } from '@mui/material';
import { useNavigate } from 'react-router-dom';

const ProtectedPage = () => {
  const navigate = useNavigate();
  const [userRole, setUserRole] = useState(null); // State to store the user's role
  const [loading, setLoading] = useState(true); // Loading state to simulate API request

  useEffect(() => {
    const fetchUserRole = async () => {
      // Simulating fetching user role from context or API (replace with actual logic)
      try {
        // For demonstration, we simulate an API call that retrieves user role.
        const role = await getUserRole(); // Replace this with actual logic
        setUserRole(role);
      } catch (error) {
        console.error("Error fetching user role:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchUserRole();
  }, []);

  // Mock function to simulate fetching user role (replace with real implementation)
  const getUserRole = async () => {
    // Simulating a delay
    return new Promise((resolve) => setTimeout(() => resolve('admin'), 1000)); // Return 'admin' or 'editor'
  };

  // Redirect to login if user does not have the required role
  useEffect(() => {
    if (loading === false && (userRole !== 'admin' && userRole !== 'editor')) {
      navigate('/login'); // Redirect to login if the user role is not admin or editor
    }
  }, [loading, userRole, navigate]);

  return (
    <Box sx={{ flexGrow: 1, bgcolor: 'background.default', p: 3 }}>
      {/* Check if user is loading */}
      {loading ? (
        <Typography variant="h6" color="textSecondary" align="center">
          Loading...
        </Typography>
      ) : (
        <Container sx={{ mt: 4 }}>
          <Typography variant="h3" gutterBottom align="center">
            Protected Admin/Editor Page
          </Typography>

          <Typography variant="h5" gutterBottom>
            Welcome to the protected content, visible only to Admins and Editors.
          </Typography>

          <Grid container spacing={3} justifyContent="center">
            <Grid item xs={12} sm={6}>
              <Paper sx={{ p: 3, display: 'flex', flexDirection: 'column', height: '100%' }}>
                <Typography variant="h6" gutterBottom>
                  Admin/Editor Only Feature
                </Typography>
                <Typography variant="body1" color="textSecondary">
                  As an admin or editor, you have access to view and manage important resources within the platform.
                  You can manage users, edit settings, and access exclusive content that regular users cannot.
                </Typography>
              </Paper>
            </Grid>
          </Grid>

         
        </Container>
      )}
    </Box>
  );
};

export default ProtectedPage;
