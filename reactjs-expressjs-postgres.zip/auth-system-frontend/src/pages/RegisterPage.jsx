import React from 'react';
import { Container, Box } from '@mui/material';
import RegistrationForm from '../components/forms/RegisterForm';

const RegisterPage = () => {
  return (
    <Container component="main" maxWidth="xs" style={{ height: '100vh' }}>
      <Box
        display="flex"
        flexDirection="column"
        justifyContent="center"
        alignItems="center"
        height="100%"
      >
        <RegistrationForm />
      </Box>
    </Container>
  );
};

export default RegisterPage;