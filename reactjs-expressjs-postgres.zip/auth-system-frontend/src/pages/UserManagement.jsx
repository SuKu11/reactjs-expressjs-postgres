import React, { useEffect, useState } from 'react';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Button, CircularProgress, Typography, Divider , Container} from '@mui/material';

const UserManagement = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true); // Track loading state

  useEffect(() => {
    // Fetching the users from the API (replace with your own backend endpoint)
    const fetchUsers = async () => {
      try {
        const response = await fetch(`${process.env.REACT_APP_API_BASE_URL}/users`); // Adjust endpoint as needed
        const data = await response.json();
        setUsers(data);
      } catch (error) {
        console.error("Error fetching users:", error);
      } finally {
        setLoading(false); // Set loading to false after data is fetched
      }
    };

    fetchUsers();
  }, []);

  const deleteUser = (id) => {
    // Logic for deleting a user (replace with your own backend logic)
    console.log(`Deleting user with ID: ${id}`);
  };

  return (
    <div>
      <Container>
      <Typography variant="h4" gutterBottom>
        User Table
      </Typography>
      {/* <Button variant="contained" color="primary" style={{ marginBottom: '16px' }}>
        Add User
      </Button> */}
      <TableContainer>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>ID</TableCell>
              <TableCell>Name</TableCell>
              <TableCell>Email</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={4} align="center">
                  <CircularProgress size={50} />
                </TableCell>
              </TableRow>
            ) : users.length === 0 ? (
              <TableRow>
                <TableCell colSpan={4} align="center">
                  <Typography variant="h6" color="textSecondary">
                    No data available.
                  </Typography>
                </TableCell>
              </TableRow>
            ) : (
              users.map((user) => (
                <TableRow key={user.id}>
                  <TableCell>{user.id}</TableCell>
                  <TableCell>{user.name}</TableCell>
                  <TableCell>{user.email}</TableCell>
                  <TableCell>
                    <Button color="primary" onClick={() => console.log(`Editing user with ID: ${user.id}`)} style={{ marginRight: '8px' }}>
                      Edit
                    </Button>
                    <Button color="secondary" onClick={() => deleteUser(user.id)}>
                      Delete
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </TableContainer>
      <Divider style={{ marginTop: '16px' }} />
      </Container>
    </div>
  );
};

export default UserManagement;
