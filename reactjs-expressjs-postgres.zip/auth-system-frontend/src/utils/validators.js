// Utility function to validate email format
export const validateEmail = (email) => {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(email);
  };
  
  // Utility function to validate password (minimum 8 characters, 1 number, 1 uppercase letter)
  export const validatePassword = (password) => {
    const passwordRegex = /^(?=.*[A-Z])(?=.*\d)[A-Za-z\d@$!%*?&]{8,}$/;
    return passwordRegex.test(password);
  };
  
  // Utility function to validate that a field is not empty
  export const validateRequired = (value) => {
    return value.trim() !== '';
  };
  
  // Utility function to validate that a password and confirm password match
  export const validatePasswordMatch = (password, confirmPassword) => {
    return password === confirmPassword;
  };
  
  // Utility function to validate phone numbers (example: US format)
  export const validatePhoneNumber = (phoneNumber) => {
    const phoneRegex = /^\(?\d{3}\)?[\s\-]?\d{3}[\s\-]?\d{4}$/;
    return phoneRegex.test(phoneNumber);
  };
  
  // Utility function to validate a name (only letters and spaces)
  export const validateName = (name) => {
    const nameRegex = /^[a-zA-Z\s]+$/;
    return nameRegex.test(name);
  };
  