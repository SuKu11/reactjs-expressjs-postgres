import React, { useState } from "react";
import {
  Toolbar,
  IconButton,
  Typography,
  Drawer,
  List,
  ListItem,
  ListItemText,
  Divider,
} from "@mui/material";
import { Menu as MenuIcon } from "@mui/icons-material";
import { Link, Outlet } from "react-router-dom"; // This is used for React Router for nested routes
import CustomAppBar from "../CustomAppBar";


const AuthLayout = () => {
  const [openDrawer, setOpenDrawer] = useState(false);

  const handleDrawerToggle = () => {
    setOpenDrawer(!openDrawer);
  };

  const drawerWidth = 240;

  return (
    <div >
      <CustomAppBar />

      {/* Main Content */}
      <main style={{ padding: "16px", marginTop: "64px", flexGrow: 1 }}>
        {/* This is where page content will be injected */}
        <Outlet />
      </main>
    </div>
  );
};

export default AuthLayout;
