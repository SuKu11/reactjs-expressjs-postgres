import React from 'react';
import { Outlet } from 'react-router-dom'; // This will render the child routes like RegisterPage or LoginPage

const BlankLayout = () => {
  return (
    <div>
      {/* No AppBar, No Drawer, Just Render the Page Content */}
      <Outlet />  
    </div>
  );
};

export default BlankLayout;
