import React, { createContext, useState, useEffect } from 'react';

// Create a context for authentication
export const AuthContext = createContext();

// AuthProvider component that will wrap the app and provide authentication state
export const AuthProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    // Check for authentication state from localStorage or an API call (mocked here)
    const token = localStorage.getItem('authToken');
    if (token) {
      // Assuming the token also includes user role info or you can fetch it via API
      const userRole = localStorage.getItem('userRole'); // Mocked role
      setIsAuthenticated(true);
      setIsAdmin(userRole === 'admin');
    } else {
      setIsAuthenticated(false);
      setIsAdmin(false);
    }
  }, []);

  // Login method to set authentication state
  const login = (token, userRole) => {
    localStorage.setItem('authToken', token);
    localStorage.setItem('userRole', userRole);
    setIsAuthenticated(true);
    setIsAdmin(userRole === 'admin');
  };

  // Logout method to clear authentication state
  const logout = () => {
    localStorage.removeItem('authToken');
    localStorage.removeItem('userRole');
    setIsAuthenticated(false);
    setIsAdmin(false);
  };

  return (
    <AuthContext.Provider
      value={{
        isAuthenticated,
        isAdmin,
        login,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
