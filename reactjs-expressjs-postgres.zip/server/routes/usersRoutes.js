const express = require("express");
const { fetchAllUsers } = require("../controllers/userController");
const router = express.Router();

router.post("/allusers", fetchAllUsers);


module.exports = router;
