const express = require("express");
const cors = require("cors");
const { sequelize } = require("./models");
const authRoutes = require("./routes/authRoutes");
const usersRoutes = require("./routes/usersRoutes");

const app = express();
app.use(express.json());

// Enable CORS
app.use(cors({
  origin: "http://localhost:3000", // Allow only your frontend origin
  methods: ["GET", "POST", "PUT", "DELETE"], // Allow necessary methods
  credentials: true, // If you're handling cookies or credentials
}));

app.use("/auth", authRoutes);
app.use("/api/user", usersRoutes);


const PORT = process.env.PORT || 5000;
sequelize.sync().then(() => {
  app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
});
