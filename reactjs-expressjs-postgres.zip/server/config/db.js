const creds = {
  development: {
    username: "postgres",
    password: "Password@123",
    database: "postgres",
    host: "localhost",
    dialect: "postgres",
  },
  test: {
    username: "postgres",
    password: "Password@123",
    database: "postgres",
    host: "localhost",
    dialect: "postgres",
  },
  production: {
    username: "postgres",
    password: "Password@123",
    database: "postgres",
    host: "localhost",
    dialect: "postgres",
  },
};
module.exports = creds;
