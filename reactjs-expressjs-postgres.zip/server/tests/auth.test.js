
const request = require('supertest');
const app = require('../server'); // Make sure this is the correct path to your app

describe('POST /api/auth/register', () => {
  it('should register a new user and return a success response', async () => {
    const newUser = {
      username: 'testuser',
      password: 'Password@123',
    };

    const response = await request(app) // Make sure app is the express app
      .post('/api/auth/register')
      .send(newUser)
      .set('Accept', 'application/json');

    // Check if the response status code is 200 (OK)
    expect(response.status).toBe(200);

    // Check if the response body contains the expected fields
    expect(response.body).toHaveProperty('message', 'User registered successfully');
    expect(response.body).toHaveProperty('user'); // assuming user object is returned

    // Additional checks for user data
    expect(response.body.user.username).toBe(newUser.username);
  });

  it('should return an error if username or password is missing', async () => {
    const invalidUser = {
      username: '', // empty username
      password: 'Password@123',
    };

    const response = await request(app)
      .post('/api/auth/register')
      .send(invalidUser)
      .set('Accept', 'application/json');

    // Check if the response status code is 400 (Bad Request)
    expect(response.status).toBe(400);

    // Check if the error message is returned
    expect(response.body).toHaveProperty('error', 'Username is required');
  });
});
